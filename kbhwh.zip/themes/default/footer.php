            </div>
        </div>
    </div>
	<!-- script references -->
    <script src="<?php echo Request::base_url()?>/assets/js/jquery-2.0.2.min.js"></script>
    <script src="<?php echo Request::base_url()?>/assets/js/bootstrap.min.js"></script>
		<script src="<?php echo Request::base_url()?>/assets/js/scripts.js"></script>
	</body>
</html>