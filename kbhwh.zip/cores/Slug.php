<?php
/*
 * kelas berfungsi membaca slug url
 */

class Slugurl
{
    
}