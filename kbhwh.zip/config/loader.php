<?php
require_once 'cores/Autoload.php';
Autoload::register();

