<?php
return array(
    'db' => array(
        'host' => 'localhost', // 127.0.0.1
        'port' => '3306', // default mysql
        'username' => 'kbhwh',
        'password' => 'kbhwh',
        'dbname' => 'kbhwh',
    ),
    'timezone' => 'Asia/Jakarta',
    'salt' => 'AB87@#5edV!3s)98s^7_9*6HNM%$))$%Has34bk98s*9)&S$@sda',
    'base_include' => array(
        'views' => 'themes',
        'controllers' => 'controller',
    ),
    'slug' => array (
        'article' => 'article',
        'category' => 'category',
    ),
    'host'=>'http://kb.helloworldhost.com',
);